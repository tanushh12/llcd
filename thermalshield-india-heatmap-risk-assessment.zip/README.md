# ThermalShield — Visily-inspired SIH prototype

Updated with a full India state/UT heat-zone map and a more detailed localized risk-assessment panel.

## Map fix
The previous map depended on a runtime GeoJSON fetch, which can fail when the ZIP is opened directly from the filesystem. This version uses the amCharts India state geodata layer loaded as a script, then colors each state polygon from the prototype risk score. amCharts documents its map/geodata CDN approach, and the India state map is commonly used as `indiaLow`.

## Risk assessment additions
- 0–100 composite risk score
- Extreme / High / Moderate / Low tiers
- Heat-load, humidity, solar and low-wind components
- Action tier with public-health response suggestions
- National risk distribution
- Methodology/production-data guidance
- State/UT click-through to city profile

The prototype values remain illustrative and should be replaced with validated weather/model data before operational use.
