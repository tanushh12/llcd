# ThermalShield — Visily-inspired SIH prototype

This package preserves the earlier prototype's core functionality while applying the visual language from the supplied 7-screen Visily PDF: dark command-center UI, compact left navigation, blue primary controls, red/orange warning states, dense operational cards, GIS screen, thermal trend screen and intervention hub. The supplied PDF was image-based, so visual details were matched from the rendered screens rather than extracted text. fileciteturn1file0L12-L18

## Kept intact
- 28 states + 8 Union Territories
- 50 representative cities
- City-specific metrics and risk curves
- 24-hour forecast on its own subpage
- Geographic India GIS map
- Alerts and intervention controls
- No real alerts/infrastructure actions are triggered

## Visual changes only
- Visily-style dark command-center layout
- Sidebar/navigation hierarchy
- Dense metric cards
- Operational alert panel
- GIS heat-map page
- Intervention command page
- Monospace telemetry labels and compact controls
- Blue/red critical-state visual language

The map boundary layer is loaded at runtime from the India state GeoJSON source used by the prototype. Demo risk/weather values remain illustrative.
